from flask import Flask, render_template, request
import google.generativeai as genai

app = Flask(__name__)

# Configure generative AI
genai.configure(api_key="AIzaSyAy4y7m1xMkhiOw-JwRK2bfyca1WtbFM1g")

# Set up the model
generation_config = {
    "temperature": 0.9,
    "top_p": 1,
    "top_k": 1,
    "max_output_tokens": 2048,
}

safety_settings = [
    {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
    {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
    {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_MEDIUM_AND_ABOV>
    {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_MEDIUM_AND_ABOV>
]

model = genai.GenerativeModel(
    model_name="gemini-1.0-pro", generation_config=generation_config, safety_settings=s>
)


@app.route('/')
def index():
    return render_template('index2.html')


@app.route('/generate_response', methods=['POST'])
def generate_response():
    user_input = request.form['user_input']
    convo = model.start_chat(history=[])
    convo.send_message(user_input)
    response = convo.last.text
    return response


if __name__ == '__main__':
    app.run(debug=True)